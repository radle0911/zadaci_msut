#ifndef __RTC_H_
#define __RTC_H_

#include "stm32f4xx.h"
#include "misc.h"

void 		initRTC(void);	
uint8_t * 	getRTC(void);
 

#endif 
